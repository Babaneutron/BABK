        // color switcher
        var colorSheets = [
        {
            color: "#3140fc",
            title: "Blue to Red",
            href: "./color/default.css"
        },
        {
            color: "#1fa69a",
            title: "Cyan to Orange",
            href: "./color/cyan.css"
        },
        {
            color: "#0674ec",
            title: "Blue to Orange",
            href: "./color/blue.css"
        },
        {
            color: "#2e9e04",
            title: "Green to Violet",
            href: "./color/green.css"
        },
        {
            color: "#58c9e9",
            title: "Sky",
            href: "./color/sky.css"
        },
        {
            color: "#ff6a6d",
            title: "Red",
            href: "./color/red.css"
        }

    ];

    ColorSwitcher.init(colorSheets);  
      
      

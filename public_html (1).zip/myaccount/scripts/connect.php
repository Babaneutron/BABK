<?php
$servername = "localhost";
$username = "u562324072_starur";
$password = "oxTuKw9D~";
$dbname = "u562324072_stardb";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {

  die("Connection failed: " . $conn->connect_error);

}

?>
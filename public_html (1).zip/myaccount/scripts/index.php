<html>
<head>
	<title>Access Denied</title>
</head>
<body>
	<center>
		<h1 style="color: red">Oops!</h1>
  <h2 style="color: gray">Direct page Access Dinied!</h2>
</center>
</body>
</html>
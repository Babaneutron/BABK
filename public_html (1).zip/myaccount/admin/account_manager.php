
<script type="text/javascript">
    window.location.href='users';
</script>
